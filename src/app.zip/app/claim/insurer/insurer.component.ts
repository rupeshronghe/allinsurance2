import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-insurer',
  templateUrl: './insurer.component.html',
  styleUrls: ['./insurer.component.css']
})
export class InsurerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
