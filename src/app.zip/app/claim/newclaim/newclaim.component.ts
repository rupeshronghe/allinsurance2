import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newclaim',
  templateUrl: './newclaim.component.html',
  styleUrls: ['./newclaim.component.css']
})
export class NewclaimComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
