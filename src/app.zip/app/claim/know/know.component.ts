import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-know',
  templateUrl: './know.component.html',
  styleUrls: ['./know.component.css']
})
export class KnowComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
